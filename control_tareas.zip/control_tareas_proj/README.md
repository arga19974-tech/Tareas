# Control de tareas (Django)

Aplicación web para llevar el control de tareas con fecha de inicio, fecha de fin (opcional),
calidad del trabajo, porcentaje de avance, prioridad, área, días de la semana (opcional), usuario que
asigna, usuario que realiza, reasignación con historial, roles, comentarios y bitácora por tarea, importación y exportación a Excel y
administración de usuarios y áreas dentro de la app.

## Puesta en marcha

```bash
python -m venv venv
source venv/bin/activate        # En Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Abre http://127.0.0.1:8000/ e inicia sesión. Si actualizas desde una versión anterior, vuelve a ejecutar
`pip install -r requirements.txt` (se agregó `openpyxl` para leer Excel) y `python manage.py migrate`.

## Configuración inicial

Entra con el usuario creado con `createsuperuser` (tiene rol Administración) y usa los menús **Áreas** y
**Usuarios** de la aplicación:

1. **Áreas**: crea las áreas (por ejemplo Sistemas, RRHH, Contabilidad).
2. **Usuarios**: crea cada usuario con **nombre, usuario, contraseña, área y rol** (nada más).

También puedes hacerlo desde `/admin/` (el formulario de usuario tiene los mismos campos). Los
superusuarios siempre tienen permisos de Administración y solo los ven otros superusuarios.

## Roles

| | Atención | Administración |
|---|---|---|
| Ve | Solo las tareas de su área (y las suyas) | Todas las áreas |
| Agrega tareas | Sí. El área no se elige: se toma sola (la del responsable; si no tiene, la de quien la crea). Solo asigna a usuarios de su área | Sí, igual; puede asignar a cualquier usuario |
| Actualiza avance y calidad | De las tareas que atiende o asignó | De cualquier tarea |
| Edita, reasigna y elimina | Solo las tareas que él asignó | Cualquier tarea |
| Importa / exporta Excel | Sí, solo su área | Sí, todas las áreas |
| Comentarios y bitácora | Los de las tareas que ve | Todas |
| Administra usuarios y áreas | No | Sí (menús Usuarios y Áreas) |
| Dashboard | Su área | Elige área o ve todas (con gráfico por área) |

Un usuario de Atención sin área asignada no puede agregar ni importar tareas hasta que un administrador
le asigne un área. Cada reasignación se guarda en el historial (de quién, a quién, quién la hizo, fecha y
motivo).

## Tareas por día de la semana (opcional)

Al crear o editar una tarea puedes marcar uno o varios días de **lunes a viernes** (por ejemplo lunes y
miércoles). Si no marcas ninguno, la tarea funciona como siempre. Las tareas con días aparecen en la
tarjeta **Para hoy** del dashboard cuando hoy es uno de sus días (dentro de su rango de fechas y sin
estar completada). Sábado y domingo no se programan. La lista se puede filtrar por día.

## Prioridad

Cada tarea tiene prioridad Baja, Media (por defecto), Alta o Crítica. Se ve como etiqueta de color en la
lista y el detalle, y en la lista se puede filtrar y ordenar por prioridad.

## Comentarios y bitácora

Cada tarea tiene una sección **Comentarios y bitácora**: cualquiera que pueda ver la tarea agrega notas
(con fecha y autor). Además, la bitácora registra sola los movimientos: creación, edición, cambios de
avance y calidad, reasignaciones e importaciones. Al actualizar el avance se puede dejar una nota.

## Exportar a Excel

Menú **Exportar**: filtra por área (Administración), usuario, prioridad, estado y rango de fechas
(de inicio, de fin o de creación) y descarga un libro con las hojas **Resumen**, **Tareas** y, si
quieres, **Bitácora**. Solo se exportan las tareas que el usuario puede ver.

## Usuarios y áreas dentro de la app

Con rol Administración aparecen los menús **Usuarios** (alta, edición, cambio de área o rol,
activar/desactivar, cambio de contraseña) y **Áreas** (crear, renombrar, eliminar si no tiene usuarios
ni tareas). No puedes cambiar tu propio rol ni desactivarte.

## Importar tareas desde Excel

1. Entra a **Importar** en el menú y pulsa **Descargar plantilla** (trae filas de ejemplo, la lista de
   usuarios a los que puedes asignar tareas y listas desplegables). También hay una copia en
   `plantilla_tareas.xlsx`.
2. Llena la hoja **Tareas**, una fila por tarea. Las filas 2 a 5 son ejemplos (empiezan con
   «(Ejemplo)») y se ignoran.
3. Sube el archivo en la misma pantalla.

Columnas: Título (obligatoria), Descripción, Responsable (usuario, obligatoria), Prioridad, Fecha inicio,
Fecha fin, Días (lunes a viernes), Avance % y Calidad. El área de cada tarea es la del responsable. La hoja
**Instrucciones** de la plantilla explica cada una.

La importación es de "todo o nada": si alguna fila tiene errores no se guarda ninguna y se muestra la
fila y la columna a corregir. Máximo 500 tareas por archivo.

## Dashboard (página principal)

Tiene dos vistas: **Mi resumen** (solo mis tareas) y **Equipo** (mi área; Administración puede elegir otra
área o todas).

- Tarjetas: total, pendientes, completadas, vencidas y avance promedio.
- Para hoy: tareas programadas para el día de hoy (lunes a viernes).
- Urgentes: tareas abiertas vencidas, que vencen en los próximos 7 días o de prioridad Alta/Crítica, y
  aviso de tareas sin fecha de fin.
- Gráficos: estado (sin iniciar / en progreso / completadas), calidad del trabajo, prioridad de las tareas
  abiertas, tareas por área (Administración) y carga por usuario (Equipo).
- Actividad reciente: tareas actualizadas y últimas reasignaciones.

Los gráficos usan Chart.js desde un CDN, así que necesitan internet. Sin conexión se siguen viendo las
tarjetas y tablas.

## Estructura

- `tareas/models.py`: `Area`, `PerfilUsuario` (área y rol), `Tarea`, `Reasignacion` y `Comentario`
- `tareas/permisos.py`: roles y visibilidad por área
- `tareas/views.py`: dashboard, lista con filtros, crear, detalle, editar, avance, reasignar, eliminar,
  importar
- `tareas/importacion.py`: lectura del Excel y generación de la plantilla
- `tareas/exportacion.py`: reporte de Excel con filtros
- `tareas/gestion.py`: administración de usuarios y áreas
- `templates/`: plantillas HTML
