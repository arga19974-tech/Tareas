from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.urls import reverse
from django.utils import timezone


DIAS_NOMBRES = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
# Las tareas por día solo se programan de lunes a viernes.
DIAS_SEMANA = [(n, DIAS_NOMBRES[n]) for n in range(5)]


class Area(models.Model):
    nombre = models.CharField("Nombre", max_length=100, unique=True)
    descripcion = models.CharField("Descripción", max_length=255, blank=True)

    class Meta:
        ordering = ["nombre"]
        verbose_name = "área"
        verbose_name_plural = "áreas"

    def __str__(self):
        return self.nombre


class PerfilUsuario(models.Model):
    """Datos extra del usuario: el área a la que pertenece y su rol."""

    class Rol(models.TextChoices):
        ATENCION = "atencion", "Atención (atiende y agrega tareas)"
        ADMINISTRACION = "administracion", "Administración (gestiona todas las áreas)"

    usuario = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="perfil"
    )
    area = models.ForeignKey(
        Area,
        verbose_name="Área",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="usuarios",
    )
    rol = models.CharField(
        "Rol",
        max_length=20,
        choices=Rol.choices,
        default=Rol.ATENCION,
    )

    class Meta:
        verbose_name = "perfil de usuario"
        verbose_name_plural = "perfiles de usuario"

    def __str__(self):
        return f"Perfil de {self.usuario}"


class Tarea(models.Model):
    class Calidad(models.TextChoices):
        SIN_EVALUAR = "sin_evaluar", "Sin evaluar"
        DEFICIENTE = "deficiente", "Deficiente"
        REGULAR = "regular", "Regular"
        BUENA = "buena", "Buena"
        EXCELENTE = "excelente", "Excelente"

    class Prioridad(models.IntegerChoices):
        BAJA = 1, "Baja"
        MEDIA = 2, "Media"
        ALTA = 3, "Alta"
        CRITICA = 4, "Crítica"

    titulo = models.CharField("Título", max_length=200)
    descripcion = models.TextField("Descripción", blank=True)
    fecha_inicio = models.DateField("Fecha de inicio", default=timezone.localdate)
    fecha_fin = models.DateField("Fecha de fin (opcional)", null=True, blank=True)
    calidad = models.CharField(
        "Calidad del trabajo",
        max_length=20,
        choices=Calidad.choices,
        default=Calidad.SIN_EVALUAR,
    )
    prioridad = models.PositiveSmallIntegerField(
        "Prioridad",
        choices=Prioridad.choices,
        default=Prioridad.MEDIA,
    )
    area = models.ForeignKey(
        Area,
        verbose_name="Área",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="tareas",
        help_text="Si la dejas vacía se usa el área del responsable.",
    )
    dias_semana = models.CharField(
        "Días de la semana",
        max_length=20,
        blank=True,
        help_text="Opcional. Días en que se repite la tarea, de lunes a viernes (por ejemplo lunes y miércoles).",
    )
    porcentaje_avance = models.PositiveSmallIntegerField(
        "Porcentaje de avance",
        default=0,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )
    asignado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name="Asignado por",
        on_delete=models.PROTECT,
        related_name="tareas_asignadas",
    )
    responsable = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name="Usuario que realiza la tarea",
        on_delete=models.PROTECT,
        related_name="tareas_a_realizar",
    )
    creada_en = models.DateTimeField(auto_now_add=True)
    actualizada_en = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-creada_en"]

    def __str__(self):
        return self.titulo

    def clean(self):
        if self.fecha_fin and self.fecha_inicio and self.fecha_fin < self.fecha_inicio:
            raise ValidationError(
                {"fecha_fin": "La fecha de fin no puede ser anterior a la fecha de inicio."}
            )

    def save(self, *args, **kwargs):
        # El área no se elige: se toma la del responsable y, si este no tiene,
        # la de quien asigna la tarea.
        if self.area_id is None:
            for usuario_id, relacion in (
                (self.responsable_id, "responsable"),
                (self.asignado_por_id, "asignado_por"),
            ):
                if not usuario_id:
                    continue
                perfil = getattr(getattr(self, relacion), "perfil", None)
                if perfil is not None and perfil.area_id:
                    self.area_id = perfil.area_id
                    campos = kwargs.get("update_fields")
                    if campos is not None:
                        kwargs["update_fields"] = {*campos, "area"}
                    break
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse("tareas:detalle", kwargs={"pk": self.pk})

    def registrar_evento(self, autor, texto):
        """Agrega una entrada automática a la bitácora de la tarea."""
        return self.comentarios.create(autor=autor, tipo=Comentario.Tipo.EVENTO, texto=texto)

    @property
    def dias_lista(self):
        return [d for d in self.dias_semana.split(",") if d]

    @property
    def dias_texto(self):
        nombres = {str(n): nombre for n, nombre in DIAS_SEMANA}
        return ", ".join(nombres[d] for d in self.dias_lista if d in nombres)

    @property
    def completada(self):
        return self.porcentaje_avance >= 100

    @property
    def vencida(self):
        return bool(
            self.fecha_fin and not self.completada and self.fecha_fin < timezone.localdate()
        )


class Reasignacion(models.Model):
    tarea = models.ForeignKey(Tarea, on_delete=models.CASCADE, related_name="reasignaciones")
    de_usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+"
    )
    a_usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+"
    )
    realizada_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+"
    )
    motivo = models.CharField("Motivo", max_length=255, blank=True)
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-fecha"]

    def __str__(self):
        return f"{self.tarea} : {self.de_usuario} -> {self.a_usuario}"


class Comentario(models.Model):
    """Notas de avance (escritas por personas) y eventos automáticos de la bitácora."""

    class Tipo(models.TextChoices):
        NOTA = "nota", "Nota"
        EVENTO = "evento", "Evento"

    tarea = models.ForeignKey(Tarea, on_delete=models.CASCADE, related_name="comentarios")
    autor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+"
    )
    tipo = models.CharField(max_length=10, choices=Tipo.choices, default=Tipo.NOTA)
    texto = models.TextField("Comentario")
    creado_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-creado_en", "-id"]
        verbose_name = "comentario"
        verbose_name_plural = "comentarios y bitácora"

    def __str__(self):
        return f"{self.tarea}: {self.texto[:40]}"
