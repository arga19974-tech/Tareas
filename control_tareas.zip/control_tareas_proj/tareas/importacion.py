"""Importación de tareas desde Excel y generación de la plantilla (.xlsx).

La importación es de "todo o nada": se validan todas las filas y, si alguna tiene errores,
no se guarda ninguna y se informa fila y columna de cada problema.
"""

import io
import re
import unicodedata
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone
from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils.datetime import from_excel
from openpyxl.worksheet.datavalidation import DataValidation

from .models import Tarea
from .permisos import usuarios_asignables

MAX_FILAS = 500
MAX_ERRORES = 200
HOJA_TAREAS = "Tareas"
FUENTE = "Arial"

# (clave, encabezado en la plantilla, obligatoria, ancho de columna)
COLUMNAS = [
    ("titulo", "Título *", True, 38),
    ("descripcion", "Descripción", False, 42),
    ("responsable", "Responsable (usuario) *", True, 24),
    ("prioridad", "Prioridad", False, 12),
    ("fechainicio", "Fecha inicio", False, 14),
    ("fechafin", "Fecha fin", False, 14),
    ("dias", "Días (lunes a viernes)", False, 24),
    ("avance", "Avance %", False, 11),
    ("calidad", "Calidad", False, 14),
]
ENCABEZADO = {clave: enc for clave, enc, _, _ in COLUMNAS}
CLAVES = set(ENCABEZADO)
ALIAS = {"fechadeinicio": "fechainicio", "fechadefin": "fechafin"}

PRIORIDADES = {"baja": 1, "media": 2, "alta": 3, "critica": 4, "1": 1, "2": 2, "3": 3, "4": 4}
DIAS = {
    "lunes": 0, "lun": 0,
    "martes": 1, "mar": 1,
    "miercoles": 2, "mie": 2,
    "jueves": 3, "jue": 3,
    "viernes": 4, "vie": 4,
}
DIAS_FIN_DE_SEMANA = {"sabado", "sab", "domingo", "dom"}
TODOS_LOS_DIAS = {"todos", "todoslosdias", "lunesaviernes", "lav"}


def _norm(texto):
    """Minúsculas, sin acentos y solo letras/números (para comparar textos)."""
    texto = unicodedata.normalize("NFKD", str(texto)).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]", "", texto.lower())


CALIDADES = {}
for _valor, _etiqueta in Tarea.Calidad.choices:
    CALIDADES[_norm(_etiqueta)] = _valor
    CALIDADES[_norm(_valor)] = _valor


def _texto(valor):
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        valor = int(valor)
    return str(valor).strip()


def _a_fecha(valor):
    if isinstance(valor, datetime):
        return valor.date()
    if isinstance(valor, date):
        return valor
    if isinstance(valor, (int, float)) and not isinstance(valor, bool):
        try:
            return from_excel(valor).date()
        except (ValueError, OverflowError, TypeError):
            return None
    texto = str(valor).strip()
    for formato in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%d/%m/%y"):
        try:
            return datetime.strptime(texto, formato).date()
        except ValueError:
            continue
    return None


def _parse_dias(texto):
    """'Lunes, Miércoles' -> ('0,2', None). Devuelve (valor, mensaje_de_error)."""
    if _norm(texto) in TODOS_LOS_DIAS:
        return "0,1,2,3,4", None
    elegidos = set()
    for parte in re.split(r"[,;/\s]+", texto):
        clave = _norm(parte)
        if not clave or clave == "y":
            continue
        if clave in DIAS_FIN_DE_SEMANA:
            return None, "Solo se permiten días de lunes a viernes."
        if clave not in DIAS:
            return None, f"Día no válido: «{parte}». Usa lunes, martes, miércoles, jueves o viernes."
        elegidos.add(DIAS[clave])
    return ",".join(str(d) for d in sorted(elegidos)), None


def _parse_avance(celda):
    """Devuelve (entero 0-100, mensaje_de_error)."""
    valor = celda.value if celda is not None else None
    if valor is None or str(valor).strip() == "":
        return 0, None
    try:
        if isinstance(valor, str):
            numero = float(valor.strip().replace("%", "").replace(",", "."))
        else:
            numero = float(valor)
            # Celda con formato de porcentaje: 0.5 significa 50 %
            if "%" in (celda.number_format or "") and numero <= 1:
                numero *= 100
    except ValueError:
        return None, "El avance debe ser un número entre 0 y 100."
    numero = int(round(numero))
    if not 0 <= numero <= 100:
        return None, "El avance debe estar entre 0 y 100."
    return numero, None


@dataclass
class Resultado:
    creadas: int = 0
    errores: list = field(default_factory=list)
    total_errores: int = 0

    def agregar(self, fila, columna, mensaje):
        self.total_errores += 1
        if len(self.errores) < MAX_ERRORES:
            self.errores.append({"fila": fila, "columna": columna, "mensaje": mensaje})


def importar_tareas(archivo, user):
    """Valida el Excel y, si no hay errores, crea las tareas a nombre de `user`."""
    res = Resultado()
    try:
        libro = load_workbook(io.BytesIO(archivo.read()), data_only=True)
    except Exception:
        res.agregar(
            None, None,
            "No se pudo leer el archivo. Verifica que sea un .xlsx válido (usa la plantilla).",
        )
        return res

    hoja = libro[HOJA_TAREAS] if HOJA_TAREAS in libro.sheetnames else libro.active
    filas = list(hoja.iter_rows(min_row=1))
    if not filas:
        res.agregar(None, None, "El archivo está vacío.")
        return res

    # Columnas por encabezado (sin importar mayúsculas, acentos, asteriscos ni paréntesis)
    columnas = {}
    for indice, celda in enumerate(filas[0]):
        if celda.value is None:
            continue
        clave = _norm(str(celda.value).split("(")[0])
        clave = ALIAS.get(clave, clave)
        if clave in CLAVES and clave not in columnas:
            columnas[clave] = indice
    faltantes = [ENCABEZADO[c].replace(" *", "") for c in ("titulo", "responsable") if c not in columnas]
    if faltantes:
        res.agregar(
            1, None,
            "Faltan columnas obligatorias: " + ", ".join(faltantes) + ". Usa la plantilla.",
        )
        return res

    datos = [
        celdas for celdas in filas[1:]
        if any(c.value is not None and str(c.value).strip() != "" for c in celdas)
    ]
    if len(datos) > MAX_FILAS:
        res.agregar(None, None, f"El archivo tiene más de {MAX_FILAS} filas. Divídelo en varios archivos.")
        return res

    # Datos de apoyo para validar
    permitidos = {}
    por_nombre = {}
    for u in usuarios_asignables(user).select_related("perfil__area"):
        permitidos[u.get_username().lower()] = u
        nombre = u.get_full_name().strip().lower()
        if nombre:
            por_nombre.setdefault(nombre, []).append(u)
    activos = {
        n.lower() for n in get_user_model().objects.filter(is_active=True).values_list("username", flat=True)
    }
    hoy = timezone.localdate()

    pendientes = []
    for celdas in datos:
        fila = celdas[0].row

        def celda(clave):
            indice = columnas.get(clave)
            return celdas[indice] if indice is not None and indice < len(celdas) else None

        def texto(clave):
            c = celda(clave)
            return _texto(c.value) if c is not None else ""

        def error(clave, mensaje):
            res.agregar(fila, ENCABEZADO[clave].replace(" *", ""), mensaje)

        titulo = texto("titulo")
        if titulo.lower().startswith("(ejemplo)"):
            continue  # fila de ejemplo de la plantilla
        errores_antes = res.total_errores

        if not titulo:
            error("titulo", "El título es obligatorio.")
        elif len(titulo) > 200:
            error("titulo", "El título es muy largo (máximo 200 caracteres).")

        # Responsable
        responsable = None
        nombre_resp = texto("responsable")
        if not nombre_resp:
            error("responsable", "El responsable es obligatorio.")
        else:
            clave_resp = nombre_resp.lower()
            candidatos = por_nombre.get(clave_resp, [])
            if clave_resp in permitidos:
                responsable = permitidos[clave_resp]
            elif len(candidatos) == 1:
                responsable = candidatos[0]
            elif len(candidatos) > 1:
                error("responsable", f"Hay varios usuarios llamados «{nombre_resp}»; escribe el usuario (login).")
            elif clave_resp in activos:
                error("responsable", f"«{nombre_resp}» no pertenece a tu área: no puedes asignarle tareas.")
            else:
                error("responsable", f"No existe el usuario «{nombre_resp}». Revisa la hoja «Usuarios».")

        # Prioridad
        prioridad = Tarea.Prioridad.MEDIA
        texto_prioridad = texto("prioridad")
        if texto_prioridad:
            prioridad = PRIORIDADES.get(_norm(texto_prioridad))
            if prioridad is None:
                error("prioridad", "Usa Baja, Media, Alta o Crítica.")

        # Fechas
        fecha_inicio, fecha_fin = hoy, None
        c_inicio, c_fin = celda("fechainicio"), celda("fechafin")
        if c_inicio is not None and _texto(c_inicio.value):
            fecha_inicio = _a_fecha(c_inicio.value)
            if fecha_inicio is None:
                error("fechainicio", "Fecha no válida. Usa el formato dd/mm/aaaa.")
        if c_fin is not None and _texto(c_fin.value):
            fecha_fin = _a_fecha(c_fin.value)
            if fecha_fin is None:
                error("fechafin", "Fecha no válida. Usa el formato dd/mm/aaaa.")
        if fecha_inicio and fecha_fin and fecha_fin < fecha_inicio:
            error("fechafin", "La fecha de fin no puede ser anterior a la fecha de inicio.")

        # Días de la semana (opcional, lunes a viernes)
        dias_semana = ""
        texto_dias = texto("dias")
        if texto_dias:
            dias_semana, mensaje = _parse_dias(texto_dias)
            if mensaje:
                error("dias", mensaje)

        # Avance y calidad
        avance, mensaje = _parse_avance(celda("avance"))
        if mensaje:
            error("avance", mensaje)
        calidad = Tarea.Calidad.SIN_EVALUAR
        texto_calidad = texto("calidad")
        if texto_calidad:
            calidad = CALIDADES.get(_norm(texto_calidad))
            if calidad is None:
                error("calidad", "Usa Sin evaluar, Deficiente, Regular, Buena o Excelente.")

        if res.total_errores == errores_antes:
            pendientes.append(
                Tarea(
                    titulo=titulo,
                    descripcion=texto("descripcion"),
                    responsable=responsable,
                    asignado_por=user,
                    prioridad=prioridad,
                    fecha_inicio=fecha_inicio,
                    fecha_fin=fecha_fin,
                    dias_semana=dias_semana,
                    porcentaje_avance=avance,
                    calidad=calidad,
                )
            )

    if res.total_errores:
        return res
    if not pendientes:
        res.agregar(
            None, None,
            "El archivo no tiene tareas para importar (las filas de ejemplo se ignoran).",
        )
        return res

    with transaction.atomic():
        for tarea in pendientes:
            tarea.save()  # el área se toma sola (la del responsable)
            tarea.registrar_evento(
                user,
                f"Tarea importada desde Excel y asignada a "
                f"{tarea.responsable.get_full_name() or tarea.responsable.get_username()}.",
            )
    res.creadas = len(pendientes)
    return res


# --------------------------------------------------------------------------- plantilla


def _fuente(**kwargs):
    return Font(name=FUENTE, size=kwargs.pop("size", 10), **kwargs)


def generar_plantilla(usuarios):
    """Crea el libro de Excel de la plantilla.

    `usuarios` es una lista de (usuario, nombre, área) para la hoja «Usuarios».
    """
    hoy = timezone.localdate()
    libro = Workbook()

    # ---- Hoja Tareas
    hoja = libro.active
    hoja.title = HOJA_TAREAS
    obligatoria = PatternFill("solid", fgColor="1F4E79")
    opcional = PatternFill("solid", fgColor="5B7FA6")
    for numero, (clave, encabezado, requerida, ancho) in enumerate(COLUMNAS, start=1):
        celda = hoja.cell(row=1, column=numero, value=encabezado)
        celda.font = _fuente(bold=True, color="FFFFFF")
        celda.fill = obligatoria if requerida else opcional
        celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        letra = celda.column_letter
        hoja.column_dimensions[letra].width = ancho
        hoja.column_dimensions[letra].font = _fuente()
    hoja.row_dimensions[1].height = 32
    hoja.freeze_panes = "A2"
    for letra in ("E", "F"):
        hoja.column_dimensions[letra].number_format = "dd/mm/yyyy"

    u1 = usuarios[0][0] if usuarios else "usuario1"
    u2 = usuarios[1][0] if len(usuarios) > 1 else u1
    ejemplos = [
        ["(Ejemplo) Validar cierre diario", "Revisar que los registros del día estén completos",
         u1, "Alta", hoy, hoy + timedelta(days=30), "Lunes, Miércoles", 0, "Sin evaluar"],
        ["(Ejemplo) Conciliación semanal", "Comparar reportes contra el sistema",
         u2, "Media", hoy, hoy + timedelta(days=60), "Viernes", 25, "Buena"],
        ["(Ejemplo) Revisión de alertas", "Atender las alertas críticas del día",
         u1, "Crítica", hoy, None, "Lunes a viernes", 0, "Sin evaluar"],
        ["(Ejemplo) Informe mensual", "Preparar y enviar el informe del mes",
         u2, "Baja", hoy, hoy + timedelta(days=15), None, 60, "Regular"],
    ]
    for fila, ejemplo in enumerate(ejemplos, start=2):
        for numero, valor in enumerate(ejemplo, start=1):
            celda = hoja.cell(row=fila, column=numero, value=valor)
            celda.font = _fuente(italic=True, color="808080")
            if numero in (5, 6):
                celda.number_format = "dd/mm/yyyy"

    comentarios = {
        "G1": "Opcional. Ejemplos: Lunes, Miércoles  |  Lunes a viernes. No se permiten sábado ni domingo.",
        "H1": "Número de 0 a 100. Si lo dejas vacío se usa 0.",
    }
    for ref, texto in comentarios.items():
        comentario = Comment(texto, "Plantilla")
        comentario.width, comentario.height = 260, 90
        hoja[ref].comment = comentario

    def validacion(**kwargs):
        dv = DataValidation(allow_blank=True, showErrorMessage=True, **kwargs)
        hoja.add_data_validation(dv)
        return dv

    dv = validacion(type="list", formula1='"Baja,Media,Alta,Crítica"', errorTitle="Prioridad",
                    error="Elige Baja, Media, Alta o Crítica.")
    dv.add("D6:D500")
    dv = validacion(type="list", formula1='"Sin evaluar,Deficiente,Regular,Buena,Excelente"',
                    errorTitle="Calidad", error="Elige una de las opciones de la lista.")
    dv.add("I6:I500")
    dv = validacion(type="decimal", operator="between", formula1="0", formula2="100",
                    errorTitle="Avance", error="Escribe un número de 0 a 100.")
    dv.add("H6:H500")
    dv = validacion(type="list", formula1="=Usuarios!$A$2:$A$500", errorStyle="warning",
                    errorTitle="Responsable",
                    error="Ese usuario no está en la hoja «Usuarios». ¿Continuar de todos modos?")
    dv.add("C6:C500")

    # ---- Hoja Instrucciones
    ayuda = libro.create_sheet("Instrucciones")
    ayuda.column_dimensions["A"].width = 28
    ayuda.column_dimensions["B"].width = 12
    ayuda.column_dimensions["C"].width = 78
    ayuda.column_dimensions["D"].width = 30
    ayuda["A1"] = "Plantilla para importar tareas"
    ayuda["A1"].font = _fuente(bold=True, size=14)
    ayuda["A3"] = "Cómo usarla"
    ayuda["A3"].font = _fuente(bold=True, size=11)
    pasos = [
        "1. Llena la hoja «Tareas»: una fila por tarea. Las filas 2 a 5 son ejemplos (empiezan con «(Ejemplo)») "
        "y se ignoran al importar; puedes borrarlas o escribir encima.",
        "2. Encabezado azul oscuro (con *) = obligatorio. Encabezado azul claro = opcional.",
        "3. En la aplicación entra a «Importar» y sube el archivo .xlsx.",
        "4. Si alguna fila tiene errores no se importa nada: la aplicación indica la fila y la columna a corregir.",
        f"5. Máximo {MAX_FILAS} tareas por archivo. El área de cada tarea es la del responsable; las tareas quedan asignadas por quien importa.",
    ]
    for fila, paso in enumerate(pasos, start=4):
        celda = ayuda.cell(row=fila, column=1, value=paso)
        celda.font = _fuente()
        ayuda.merge_cells(start_row=fila, start_column=1, end_row=fila, end_column=4)
        celda.alignment = Alignment(wrap_text=True, vertical="top")
        ayuda.row_dimensions[fila].height = 28

    inicio_tabla = 4 + len(pasos) + 1
    for numero, titulo in enumerate(("Columna", "Obligatoria", "Qué escribir", "Ejemplo"), start=1):
        celda = ayuda.cell(row=inicio_tabla, column=numero, value=titulo)
        celda.font = _fuente(bold=True, color="FFFFFF")
        celda.fill = obligatoria
    detalle = [
        ("Título *", "Sí", "Nombre corto de la tarea (máximo 200 caracteres).", "Validar cierre diario"),
        ("Descripción", "No", "Detalle de la tarea.", "Revisar que los registros estén completos"),
        ("Responsable (usuario) *", "Sí",
         "Usuario de quien realiza la tarea, como aparece en la hoja «Usuarios» "
         "(también se acepta el nombre completo).", usuarios[0][0] if usuarios else "usuario1"),
        ("Prioridad", "No", "Baja, Media, Alta o Crítica. Si queda vacío: Media.", "Alta"),
        ("Fecha inicio", "No", "Fecha en formato dd/mm/aaaa. Si queda vacío: la fecha de hoy.",
         hoy.strftime("%d/%m/%Y")),
        ("Fecha fin", "No", "Fecha dd/mm/aaaa. No puede ser anterior a la fecha de inicio.",
         (hoy + timedelta(days=30)).strftime("%d/%m/%Y")),
        ("Días (lunes a viernes)", "No",
         "Días en que se repite la tarea, separados por coma. También sirve «Lunes a viernes». "
         "No se permiten sábado ni domingo.", "Lunes, Miércoles"),
        ("Avance %", "No", "Número de 0 a 100. Si queda vacío: 0.", "0"),
        ("Calidad", "No", "Sin evaluar, Deficiente, Regular, Buena o Excelente. Si queda vacío: Sin evaluar.",
         "Sin evaluar"),
    ]
    for desplazamiento, fila_datos in enumerate(detalle, start=1):
        for numero, valor in enumerate(fila_datos, start=1):
            celda = ayuda.cell(row=inicio_tabla + desplazamiento, column=numero, value=valor)
            celda.font = _fuente()
            celda.alignment = Alignment(wrap_text=True, vertical="top")
        ayuda.row_dimensions[inicio_tabla + desplazamiento].height = 42

    # ---- Hoja Usuarios
    hoja_usuarios = libro.create_sheet("Usuarios")
    for numero, (titulo, ancho) in enumerate((("Usuario", 24), ("Nombre", 30), ("Área", 24)), start=1):
        celda = hoja_usuarios.cell(row=1, column=numero, value=titulo)
        celda.font = _fuente(bold=True, color="FFFFFF")
        celda.fill = obligatoria
        hoja_usuarios.column_dimensions[celda.column_letter].width = ancho
    for fila, (usuario, nombre, area) in enumerate(usuarios, start=2):
        for numero, valor in enumerate((usuario, nombre, area), start=1):
            hoja_usuarios.cell(row=fila, column=numero, value=valor or None).font = _fuente()
    nota = hoja_usuarios.cell(
        row=1, column=5,
        value="Esta lista se llena con los usuarios reales cuando descargas la plantilla desde la "
        "aplicación (Importar > Descargar plantilla).",
    )
    nota.font = _fuente(italic=True, color="808080")
    hoja_usuarios.column_dimensions["E"].width = 70
    if usuarios:
        nota.value = "Usuarios a los que puedes asignar tareas (usa la columna Usuario)."

    return libro
