from .permisos import area_de, es_admin


def permisos(request):
    """Expone el rol y el área del usuario a todas las plantillas."""
    user = getattr(request, "user", None)
    if user is None or not user.is_authenticated:
        return {}
    return {"es_admin": es_admin(user), "area_usuario": area_de(user)}
