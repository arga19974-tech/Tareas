from datetime import timedelta

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Avg, Count, F, Q
from django.http import HttpResponse, HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .exportacion import aplicar_filtros, generar_excel
from .forms import (
    AvanceForm,
    ComentarioForm,
    ExportarForm,
    ImportarForm,
    ReasignarForm,
    TareaForm,
)
from .importacion import MAX_FILAS, generar_plantilla, importar_tareas
from .models import DIAS_NOMBRES, DIAS_SEMANA, Area, Reasignacion, Tarea
from .permisos import (
    area_de,
    es_admin,
    puede_avanzar,
    puede_gestionar,
    tareas_visibles,
    usuarios_asignables,
)

SIN_AREA_MSG = (
    "Tu usuario no tiene un área asignada. Pide a un administrador que te la asigne "
    "para poder agregar tareas."
)
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def _tareas(request):
    """Tareas que el usuario puede ver, con sus relaciones ya cargadas."""
    return tareas_visibles(request.user).select_related("asignado_por", "responsable", "area")


def _nombre(usuario):
    return usuario.get_full_name() or usuario.get_username()


@login_required
def dashboard(request):
    """Resumen general: vista personal (mis tareas) o de equipo (mi área / todas)."""
    hoy = timezone.localdate()
    user = request.user
    admin = es_admin(user)
    vista = request.GET.get("vista", "personal")
    if vista not in ("personal", "equipo"):
        vista = "personal"

    visibles = _tareas(request)
    areas = Area.objects.all() if admin else Area.objects.none()
    area_sel = None
    if vista == "personal":
        tareas = visibles.filter(responsable=user)
    else:
        tareas = visibles
        if admin:
            # Administración separa por área. La primera vez se muestra la propia
            # (si tiene una); "todas" muestra todas las áreas.
            area_param = request.GET.get("area")
            if area_param is None:
                mi_area = area_de(user)
                area_param = str(mi_area.pk) if mi_area else "todas"
            if area_param.isdigit():
                area_sel = Area.objects.filter(pk=int(area_param)).first()
            if area_sel:
                tareas = tareas.filter(area=area_sel)
        else:
            area_sel = area_de(user)  # el resto solo ve su área
    abiertas = tareas.filter(porcentaje_avance__lt=100)

    # 1. Tarjetas de resumen
    total = tareas.count()
    pendientes = abiertas.count()
    completadas = total - pendientes
    vencidas = abiertas.filter(fecha_fin__lt=hoy).count()
    promedio = round(tareas.aggregate(p=Avg("porcentaje_avance"))["p"] or 0)

    # 2. Urgentes: vencidas y las que vencen en los próximos 7 días
    # (o que tengan prioridad alta/crítica). Primero las de fecha más cercana.
    urgentes = abiertas.filter(
        Q(fecha_fin__lte=hoy + timedelta(days=7))
        | Q(prioridad__gte=Tarea.Prioridad.ALTA)
    ).order_by(F("fecha_fin").asc(nulls_last=True), "-prioridad")[:10]
    sin_fecha = abiertas.filter(fecha_fin__isnull=True).count()

    # Tareas que toca hacer hoy según los días de la semana marcados (lunes a viernes)
    dia_hoy = hoy.weekday()
    fin_de_semana = dia_hoy > 4
    if fin_de_semana:
        para_hoy = tareas.none()
    else:
        para_hoy = (
            abiertas.filter(dias_semana__contains=str(dia_hoy), fecha_inicio__lte=hoy)
            .filter(Q(fecha_fin__isnull=True) | Q(fecha_fin__gte=hoy))
            .order_by("-prioridad", "titulo")
        )

    # 3. Estado
    sin_iniciar = abiertas.filter(porcentaje_avance=0).count()
    en_progreso = pendientes - sin_iniciar
    estado = {
        "labels": ["Sin iniciar", "En progreso", "Completadas"],
        "values": [sin_iniciar, en_progreso, completadas],
    }

    # 4. Carga por usuario (solo vista de equipo; respeta la visibilidad y el área elegida)
    carga = []
    if vista == "equipo":
        filas = (
            abiertas.order_by()
            .values(
                "responsable__username", "responsable__first_name", "responsable__last_name"
            )
            .annotate(n=Count("id"), avance=Avg("porcentaje_avance"))
            .order_by("-n", "responsable__username")
        )
        carga = [
            {
                "nombre": f"{f['responsable__first_name']} {f['responsable__last_name']}".strip()
                or f["responsable__username"],
                "abiertas": f["n"],
                "avance": round(f["avance"] or 0),
            }
            for f in filas
        ]

    # 5. Calidad del trabajo
    por_calidad = dict(
        tareas.order_by().values_list("calidad").annotate(n=Count("id"))
    )
    calidad = {
        "keys": [k for k, _ in Tarea.Calidad.choices],
        "labels": [label for _, label in Tarea.Calidad.choices],
        "values": [por_calidad.get(k, 0) for k, _ in Tarea.Calidad.choices],
    }

    # Prioridad de las tareas abiertas
    por_prioridad = dict(
        abiertas.order_by().values_list("prioridad").annotate(n=Count("id"))
    )
    prioridad = {
        "keys": [v for v, _ in Tarea.Prioridad.choices],
        "labels": [label for _, label in Tarea.Prioridad.choices],
        "values": [por_prioridad.get(v, 0) for v, _ in Tarea.Prioridad.choices],
    }

    # Tareas abiertas por área (Administración, cuando se ven todas las áreas)
    por_area = {"labels": [], "values": []}
    if vista == "equipo" and admin and area_sel is None:
        filas = (
            abiertas.order_by()
            .values("area__nombre")
            .annotate(n=Count("id"))
            .order_by("-n")
        )
        por_area = {
            "labels": [f["area__nombre"] or "Sin área" for f in filas],
            "values": [f["n"] for f in filas],
        }

    # 6. Actividad reciente
    reasignaciones = Reasignacion.objects.select_related(
        "tarea", "de_usuario", "a_usuario", "realizada_por"
    )
    if vista == "personal":
        reasignaciones = reasignaciones.filter(Q(de_usuario=user) | Q(a_usuario=user))
    else:
        reasignaciones = reasignaciones.filter(tarea_id__in=tareas.order_by().values("pk"))
    recientes = tareas.order_by("-actualizada_en")[:5]

    charts = {
        "estado": estado,
        "calidad": calidad,
        "prioridad": prioridad,
        "area": por_area,
        "carga": {
            "labels": [c["nombre"] for c in carga],
            "values": [c["abiertas"] for c in carga],
        },
    }

    return render(
        request,
        "tareas/dashboard.html",
        {
            "vista": vista,
            "total": total,
            "pendientes": pendientes,
            "completadas": completadas,
            "vencidas": vencidas,
            "promedio": promedio,
            "urgentes": urgentes,
            "sin_fecha": sin_fecha,
            "carga": carga,
            "areas": areas,
            "area_sel": area_sel,
            "para_hoy": para_hoy[:20],
            "dia_hoy": DIAS_NOMBRES[dia_hoy],
            "fin_de_semana": fin_de_semana,
            "recientes": recientes,
            "reasignaciones": reasignaciones[:5],
            "charts": charts,
            "hoy": hoy,
        },
    )


@login_required
def lista_tareas(request):
    admin = es_admin(request.user)
    tareas = _tareas(request)

    vista = request.GET.get("vista", "mias")
    if vista == "mias":
        tareas = tareas.filter(responsable=request.user)
    elif vista == "asignadas":
        tareas = tareas.filter(asignado_por=request.user)
    # "todas": todas las que el usuario puede ver (Administración: todas las áreas)

    estado = request.GET.get("estado", "")
    hoy = timezone.localdate()
    if estado == "pendientes":
        tareas = tareas.filter(porcentaje_avance__lt=100)
    elif estado == "completadas":
        tareas = tareas.filter(porcentaje_avance__gte=100)
    elif estado == "vencidas":
        tareas = tareas.filter(porcentaje_avance__lt=100, fecha_fin__lt=hoy)

    q = request.GET.get("q", "").strip()
    if q:
        tareas = tareas.filter(Q(titulo__icontains=q) | Q(descripcion__icontains=q))

    area = request.GET.get("area", "")
    if admin and area.isdigit():
        tareas = tareas.filter(area_id=int(area))
    else:
        area = ""

    dia = request.GET.get("dia", "")
    if dia in {str(n) for n, _ in DIAS_SEMANA}:
        tareas = tareas.filter(dias_semana__contains=dia)
    else:
        dia = ""

    prioridad = request.GET.get("prioridad", "")
    if prioridad in {str(v) for v in Tarea.Prioridad.values}:
        tareas = tareas.filter(prioridad=int(prioridad))
    else:
        prioridad = ""

    orden = request.GET.get("orden", "")
    if orden == "prioridad":
        tareas = tareas.order_by("-prioridad", F("fecha_fin").asc(nulls_last=True))
    elif orden == "vence":
        tareas = tareas.order_by(F("fecha_fin").asc(nulls_last=True), "-prioridad")
    else:
        orden = ""

    return render(
        request,
        "tareas/lista.html",
        {
            "tareas": tareas,
            "vista": vista,
            "estado": estado,
            "q": q,
            "prioridad": prioridad,
            "prioridades": Tarea.Prioridad.choices,
            "orden": orden,
            "area": area,
            "areas": Area.objects.all() if admin else Area.objects.none(),
            "dia": dia,
            "dias": DIAS_SEMANA,
        },
    )


@login_required
def crear_tarea(request):
    user = request.user
    if not es_admin(user) and area_de(user) is None:
        messages.error(request, SIN_AREA_MSG)
        return redirect("tareas:lista")

    # El área no se elige: la tarea toma la del responsable (o la de quien la crea).
    form = TareaForm(request.POST or None, usuario=user, initial={"responsable": user.pk})
    if request.method == "POST" and form.is_valid():
        tarea = form.save(commit=False)
        tarea.asignado_por = user
        tarea.save()
        tarea.registrar_evento(user, f"Tarea creada y asignada a {_nombre(tarea.responsable)}.")
        messages.success(request, "Tarea creada correctamente.")
        return redirect("tareas:detalle", pk=tarea.pk)
    return render(
        request, "tareas/form.html", {"form": form, "titulo_pagina": "Nueva tarea"}
    )


@login_required
def detalle_tarea(request, pk):
    tarea = get_object_or_404(_tareas(request), pk=pk)
    return render(
        request,
        "tareas/detalle.html",
        {
            "tarea": tarea,
            "reasignaciones": tarea.reasignaciones.select_related(
                "de_usuario", "a_usuario", "realizada_por"
            ),
            "comentarios": tarea.comentarios.select_related("autor"),
            "comentario_form": ComentarioForm(),
            "puede_gestionar": puede_gestionar(request.user, tarea),
            "puede_avanzar": puede_avanzar(request.user, tarea),
            "avance_form": AvanceForm(instance=tarea),
        },
    )


@login_required
def editar_tarea(request, pk):
    tarea = get_object_or_404(_tareas(request), pk=pk)
    if not puede_gestionar(request.user, tarea):
        return HttpResponseForbidden("Solo quien asignó la tarea puede editarla.")
    form = TareaForm(request.POST or None, instance=tarea, usuario=request.user)
    if request.method == "POST" and form.is_valid():
        cambios = [
            (form.fields[campo].label or campo).replace(" (opcional)", "")
            for campo in form.changed_data
        ]
        tarea = form.save(commit=False)
        if "responsable" in form.changed_data:
            # La tarea pasa al área de la nueva persona responsable (si tiene una)
            nueva_area = area_de(tarea.responsable)
            if nueva_area is not None:
                tarea.area = nueva_area
        tarea.save()
        if cambios:
            tarea.registrar_evento(request.user, "Tarea editada: " + ", ".join(cambios) + ".")
        messages.success(request, "Tarea actualizada.")
        return redirect("tareas:detalle", pk=tarea.pk)
    return render(
        request, "tareas/form.html", {"form": form, "titulo_pagina": "Editar tarea"}
    )


@login_required
def actualizar_avance(request, pk):
    tarea = get_object_or_404(_tareas(request), pk=pk)
    if not puede_avanzar(request.user, tarea):
        return HttpResponseForbidden("No tienes permiso para actualizar esta tarea.")
    if request.method == "POST":
        avance_antes, calidad_antes = tarea.porcentaje_avance, tarea.calidad
        form = AvanceForm(request.POST, instance=tarea)
        if form.is_valid():
            form.save()
            cambios = []
            if tarea.porcentaje_avance != avance_antes:
                cambios.append(f"Avance: {avance_antes}% → {tarea.porcentaje_avance}%")
            if tarea.calidad != calidad_antes:
                etiquetas = dict(Tarea.Calidad.choices)
                cambios.append(
                    f"Calidad: {etiquetas[calidad_antes]} → {etiquetas[tarea.calidad]}"
                )
            if cambios:
                tarea.registrar_evento(request.user, "Actualización. " + " · ".join(cambios) + ".")
            nota = form.cleaned_data.get("nota", "").strip()
            if nota:
                tarea.comentarios.create(autor=request.user, texto=nota)
            messages.success(request, "Avance actualizado.")
        else:
            messages.error(request, "Revisa los datos del avance (0 a 100).")
    return redirect("tareas:detalle", pk=tarea.pk)


@login_required
def agregar_comentario(request, pk):
    """Agrega una nota a la bitácora (cualquiera que pueda ver la tarea)."""
    tarea = get_object_or_404(_tareas(request), pk=pk)
    if request.method == "POST":
        form = ComentarioForm(request.POST)
        if form.is_valid():
            tarea.comentarios.create(autor=request.user, texto=form.cleaned_data["texto"])
            messages.success(request, "Nota agregada.")
        else:
            messages.error(request, "Escribe una nota (máximo 2000 caracteres).")
    return redirect(f"{tarea.get_absolute_url()}#bitacora")


@login_required
def reasignar_tarea(request, pk):
    tarea = get_object_or_404(_tareas(request), pk=pk)
    if not puede_gestionar(request.user, tarea):
        return HttpResponseForbidden("Solo quien asignó la tarea puede reasignarla.")
    form = ReasignarForm(request.POST or None, tarea=tarea, usuario=request.user)
    if request.method == "POST" and form.is_valid():
        anterior = tarea.responsable
        nuevo = form.cleaned_data["nuevo_responsable"]
        motivo = form.cleaned_data["motivo"]
        with transaction.atomic():
            Reasignacion.objects.create(
                tarea=tarea,
                de_usuario=anterior,
                a_usuario=nuevo,
                realizada_por=request.user,
                motivo=motivo,
            )
            tarea.responsable = nuevo
            campos = ["responsable", "actualizada_en"]
            nueva_area = area_de(nuevo)
            if nueva_area is not None and tarea.area_id != nueva_area.pk:
                tarea.area = nueva_area  # la tarea pasa al área de la nueva persona
                campos.append("area")
            tarea.save(update_fields=campos)
            texto = f"Reasignada de {_nombre(anterior)} a {_nombre(nuevo)}."
            if motivo:
                texto += f" Motivo: {motivo}"
            tarea.registrar_evento(request.user, texto)
        messages.success(request, f"Tarea reasignada a {_nombre(nuevo)}.")
        return redirect("tareas:detalle", pk=tarea.pk)
    return render(request, "tareas/reasignar.html", {"form": form, "tarea": tarea})


@login_required
def eliminar_tarea(request, pk):
    tarea = get_object_or_404(_tareas(request), pk=pk)
    if not puede_gestionar(request.user, tarea):
        return HttpResponseForbidden("Solo quien asignó la tarea puede eliminarla.")
    if request.method == "POST":
        tarea.delete()
        messages.success(request, "Tarea eliminada.")
        return redirect("tareas:lista")
    return render(request, "tareas/confirmar_eliminar.html", {"tarea": tarea})


@login_required
def importar_excel(request):
    """Importa tareas desde la plantilla de Excel (todo o nada: si hay errores no se guarda nada)."""
    user = request.user
    if not es_admin(user) and area_de(user) is None:
        messages.error(request, SIN_AREA_MSG)
        return redirect("tareas:lista")

    form = ImportarForm(request.POST or None, request.FILES or None)
    resultado = None
    if request.method == "POST" and form.is_valid():
        resultado = importar_tareas(form.cleaned_data["archivo"], user)
        if not resultado.errores:
            messages.success(
                request,
                f"Se importaron {resultado.creadas} tarea{'s' if resultado.creadas != 1 else ''} correctamente.",
            )
            return redirect("tareas:lista")
    return render(
        request,
        "tareas/importar.html",
        {"form": form, "resultado": resultado, "max_filas": MAX_FILAS, "mi_area": area_de(user)},
    )


@login_required
def descargar_plantilla(request):
    """Plantilla de Excel con ejemplos y la lista de usuarios que el usuario puede asignar."""
    usuarios = [
        (
            u.get_username(),
            u.get_full_name(),
            str(u.perfil.area) if getattr(u, "perfil", None) and u.perfil.area_id else "",
        )
        for u in usuarios_asignables(request.user)
        .select_related("perfil__area")
        .order_by("username")
    ]
    libro = generar_plantilla(usuarios)
    respuesta = HttpResponse(content_type=XLSX)
    respuesta["Content-Disposition"] = 'attachment; filename="plantilla_tareas.xlsx"'
    libro.save(respuesta)
    return respuesta


@login_required
def exportar_excel(request):
    """Reporte de tareas en Excel con filtros (área, usuario, prioridad, estado y fechas)."""
    user = request.user
    if not es_admin(user) and area_de(user) is None:
        messages.error(request, SIN_AREA_MSG)
        return redirect("tareas:lista")

    form = ExportarForm(request.GET or None, usuario=user)
    total = None
    if form.is_bound and form.is_valid():
        tareas = aplicar_filtros(_tareas(request), form.cleaned_data)
        if "descargar" in request.GET:
            libro = generar_excel(
                tareas, form.cleaned_data, user, form.cleaned_data["incluir_bitacora"]
            )
            respuesta = HttpResponse(content_type=XLSX)
            nombre = f"tareas_{timezone.localdate():%Y-%m-%d}.xlsx"
            respuesta["Content-Disposition"] = f'attachment; filename="{nombre}"'
            libro.save(respuesta)
            return respuesta
        total = tareas.count()
    return render(request, "tareas/exportar.html", {"form": form, "total": total})
