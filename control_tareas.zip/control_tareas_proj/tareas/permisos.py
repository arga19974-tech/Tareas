"""Reglas de roles y visibilidad.

- Administración (rol, o superusuario): ve todas las áreas, crea/edita/reasigna/elimina cualquier
  tarea, elige el área e importa tareas de cualquier área.
- Atención: ve solo las tareas de su área (y las suyas), agrega tareas (el área se asigna sola),
  actualiza el avance de las que atiende y gestiona las que él mismo asignó.
"""

from django.contrib.auth import get_user_model
from django.db.models import Q

from .models import PerfilUsuario, Tarea


def perfil_de(user):
    return getattr(user, "perfil", None)


def es_admin(user):
    if not user.is_authenticated:
        return False
    if user.is_superuser:
        return True
    perfil = perfil_de(user)
    return perfil is not None and perfil.rol == PerfilUsuario.Rol.ADMINISTRACION


def area_de(user):
    """Área del usuario, o None si no tiene perfil o no tiene área."""
    perfil = perfil_de(user)
    return perfil.area if perfil is not None and perfil.area_id else None


def tareas_visibles(user):
    """Tareas que el usuario puede ver."""
    tareas = Tarea.objects.all()
    if es_admin(user):
        return tareas
    condicion = Q(responsable=user) | Q(asignado_por=user)
    area = area_de(user)
    if area is not None:
        condicion |= Q(area=area)
    return tareas.filter(condicion)


def puede_gestionar(user, tarea):
    """Editar, reasignar y eliminar: Administración o quien asignó la tarea."""
    return es_admin(user) or tarea.asignado_por_id == user.id


def puede_avanzar(user, tarea):
    """Actualizar avance y calidad: quien gestiona la tarea o su responsable."""
    return puede_gestionar(user, tarea) or tarea.responsable_id == user.id


def usuarios_asignables(user, incluir_pk=None):
    """Usuarios a los que `user` puede asignar tareas."""
    usuarios = get_user_model().objects.filter(is_active=True)
    if es_admin(user):
        return usuarios
    condicion = Q(pk=user.pk)
    area = area_de(user)
    if area is not None:
        condicion |= Q(perfil__area=area)
    if incluir_pk:
        condicion |= Q(pk=incluir_pk)
    return usuarios.filter(condicion).distinct()
