"""Exportación de tareas a Excel (reporte con filtros)."""

from django.utils import timezone
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .models import Comentario, Tarea

FUENTE = "Arial"

ESTADOS = [
    ("", "Todos"),
    ("pendientes", "Pendientes"),
    ("vencidas", "Vencidas"),
    ("completadas", "Completadas"),
]
CAMPOS_FECHA = [
    ("inicio", "Fecha de inicio"),
    ("fin", "Fecha de fin"),
    ("creacion", "Fecha de creación"),
]
_CAMPO_ORM = {"inicio": "fecha_inicio", "fin": "fecha_fin", "creacion": "creada_en__date"}


def aplicar_filtros(tareas, datos):
    """Filtra el queryset según los datos validados de ExportarForm."""
    hoy = timezone.localdate()
    if datos.get("area"):
        tareas = tareas.filter(area=datos["area"])
    if datos.get("responsable"):
        tareas = tareas.filter(responsable=datos["responsable"])
    if datos.get("prioridad"):
        tareas = tareas.filter(prioridad=int(datos["prioridad"]))
    estado = datos.get("estado")
    if estado == "pendientes":
        tareas = tareas.filter(porcentaje_avance__lt=100)
    elif estado == "completadas":
        tareas = tareas.filter(porcentaje_avance__gte=100)
    elif estado == "vencidas":
        tareas = tareas.filter(porcentaje_avance__lt=100, fecha_fin__lt=hoy)
    campo = _CAMPO_ORM[datos.get("campo_fecha") or "inicio"]
    if datos.get("desde"):
        tareas = tareas.filter(**{f"{campo}__gte": datos["desde"]})
    if datos.get("hasta"):
        tareas = tareas.filter(**{f"{campo}__lte": datos["hasta"]})
    return tareas.order_by("area__nombre", "fecha_inicio", "id")


def describir_filtros(datos):
    """Lista de textos con los filtros aplicados (para la hoja de resumen)."""
    lineas = []
    if datos.get("area"):
        lineas.append(f"Área: {datos['area']}")
    if datos.get("responsable"):
        r = datos["responsable"]
        lineas.append(f"Usuario que realiza la tarea: {r.get_full_name() or r.get_username()}")
    if datos.get("prioridad"):
        lineas.append(f"Prioridad: {Tarea.Prioridad(int(datos['prioridad'])).label}")
    if datos.get("estado"):
        lineas.append(f"Estado: {dict(ESTADOS)[datos['estado']]}")
    if datos.get("desde") or datos.get("hasta"):
        campo = dict(CAMPOS_FECHA)[datos.get("campo_fecha") or "inicio"]
        desde = datos["desde"].strftime("%d/%m/%Y") if datos.get("desde") else "…"
        hasta = datos["hasta"].strftime("%d/%m/%Y") if datos.get("hasta") else "…"
        lineas.append(f"{campo}: del {desde} al {hasta}")
    return lineas or ["Sin filtros (todas las tareas que puedes ver)"]


def estado_de(tarea, hoy):
    if tarea.porcentaje_avance >= 100:
        return "Completada"
    if tarea.fecha_fin and tarea.fecha_fin < hoy:
        return "Vencida"
    if tarea.porcentaje_avance == 0:
        return "Sin iniciar"
    return "En progreso"


def _nombre(usuario):
    return usuario.get_full_name() or usuario.get_username()


def _fuente(**kwargs):
    return Font(name=FUENTE, size=kwargs.pop("size", 10), **kwargs)


def _encabezados(hoja, titulos, anchos):
    relleno = PatternFill("solid", fgColor="1F4E79")
    for numero, (titulo, ancho) in enumerate(zip(titulos, anchos), start=1):
        celda = hoja.cell(row=1, column=numero, value=titulo)
        celda.font = _fuente(bold=True, color="FFFFFF")
        celda.fill = relleno
        celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        hoja.column_dimensions[get_column_letter(numero)].width = ancho
    hoja.row_dimensions[1].height = 28
    hoja.freeze_panes = "A2"


def generar_excel(tareas, datos, usuario, incluir_bitacora=False):
    """Crea el libro de Excel con las tareas filtradas."""
    hoy = timezone.localdate()
    lista = list(tareas.select_related("area", "responsable", "asignado_por"))

    libro = Workbook()

    # ---- Hoja Resumen
    resumen = libro.active
    resumen.title = "Resumen"
    resumen.column_dimensions["A"].width = 34
    resumen.column_dimensions["B"].width = 50
    resumen["A1"] = "Reporte de tareas"
    resumen["A1"].font = _fuente(bold=True, size=14)
    ahora = timezone.localtime()
    filas = [
        ("Generado por", _nombre(usuario)),
        ("Fecha de generación", ahora.strftime("%d/%m/%Y %H:%M")),
        ("", ""),
        ("Filtros aplicados", ""),
    ]
    filas += [("", linea) for linea in describir_filtros(datos)]
    completadas = sum(1 for t in lista if t.porcentaje_avance >= 100)
    vencidas = sum(1 for t in lista if estado_de(t, hoy) == "Vencida")
    promedio = round(sum(t.porcentaje_avance for t in lista) / len(lista), 1) if lista else 0
    filas += [
        ("", ""),
        ("Total de tareas", len(lista)),
        ("Pendientes", len(lista) - completadas),
        ("Completadas", completadas),
        ("Vencidas", vencidas),
        ("Avance promedio (%)", promedio),
    ]
    for numero, (etiqueta, valor) in enumerate(filas, start=3):
        a = resumen.cell(row=numero, column=1, value=etiqueta or None)
        b = resumen.cell(row=numero, column=2, value=valor if valor != "" else None)
        a.font = _fuente(bold=etiqueta in ("Filtros aplicados",))
        b.font = _fuente()
        b.alignment = Alignment(horizontal="left")

    # ---- Hoja Tareas
    hoja = libro.create_sheet("Tareas")
    titulos = [
        "ID", "Título", "Descripción", "Área", "Responsable", "Asignado por", "Prioridad",
        "Estado", "Avance %", "Calidad", "Fecha inicio", "Fecha fin", "Días", "Creada", "Actualizada",
    ]
    anchos = [7, 36, 44, 22, 24, 24, 11, 13, 10, 14, 13, 13, 22, 17, 17]
    _encabezados(hoja, titulos, anchos)
    for fila, t in enumerate(lista, start=2):
        valores = [
            t.pk, t.titulo, t.descripcion, str(t.area) if t.area_id else "Sin área",
            _nombre(t.responsable), _nombre(t.asignado_por), t.get_prioridad_display(),
            estado_de(t, hoy), t.porcentaje_avance, t.get_calidad_display(),
            t.fecha_inicio, t.fecha_fin, t.dias_texto or None,
            timezone.localtime(t.creada_en).replace(tzinfo=None),
            timezone.localtime(t.actualizada_en).replace(tzinfo=None),
        ]
        for columna, valor in enumerate(valores, start=1):
            celda = hoja.cell(row=fila, column=columna, value=valor)
            celda.font = _fuente()
            if columna in (11, 12):
                celda.number_format = "dd/mm/yyyy"
            elif columna in (14, 15):
                celda.number_format = "dd/mm/yyyy hh:mm"
            elif columna == 3:
                celda.alignment = Alignment(wrap_text=True, vertical="top")
    if lista:
        hoja.auto_filter.ref = f"A1:{get_column_letter(len(titulos))}{len(lista) + 1}"

    # ---- Hoja Bitácora (opcional)
    if incluir_bitacora:
        bitacora = libro.create_sheet("Bitácora")
        _encabezados(
            bitacora,
            ["ID tarea", "Tarea", "Fecha", "Autor", "Tipo", "Comentario"],
            [9, 36, 17, 24, 10, 80],
        )
        entradas = (
            Comentario.objects.filter(tarea_id__in=tareas.order_by().values("pk"))
            .select_related("autor", "tarea")
            .order_by("tarea_id", "creado_en", "id")
        )
        fila = 2
        for c in entradas:
            valores = [
                c.tarea_id, c.tarea.titulo,
                timezone.localtime(c.creado_en).replace(tzinfo=None),
                _nombre(c.autor), c.get_tipo_display(), c.texto,
            ]
            for columna, valor in enumerate(valores, start=1):
                celda = bitacora.cell(row=fila, column=columna, value=valor)
                celda.font = _fuente()
                if columna == 3:
                    celda.number_format = "dd/mm/yyyy hh:mm"
                elif columna == 6:
                    celda.alignment = Alignment(wrap_text=True, vertical="top")
            fila += 1
        if fila > 2:
            bitacora.auto_filter.ref = f"A1:F{fila - 1}"

    return libro
