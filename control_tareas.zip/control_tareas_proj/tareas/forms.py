from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.db import transaction

from .exportacion import CAMPOS_FECHA, ESTADOS
from .models import DIAS_SEMANA, Area, PerfilUsuario, Tarea
from .permisos import es_admin, usuarios_asignables

User = get_user_model()

MAX_BYTES_EXCEL = 5 * 1024 * 1024  # 5 MB


class UserChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        nombre = obj.get_full_name() or obj.get_username()
        perfil = getattr(obj, "perfil", None)
        if perfil is not None and perfil.area_id:
            return f"{nombre} ({perfil.area})"
        return nombre


class DateInput(forms.DateInput):
    input_type = "date"

    def __init__(self, **kwargs):
        kwargs.setdefault("format", "%Y-%m-%d")
        super().__init__(**kwargs)


def _usuarios_ordenados(queryset):
    return queryset.select_related("perfil__area").order_by("username")


class TareaForm(forms.ModelForm):
    """Alta y edición de tareas. El área no se elige: se toma sola (ver Tarea.save)."""

    responsable = UserChoiceField(
        queryset=User.objects.none(),
        label="Usuario que realiza la tarea",
    )
    dias_semana = forms.MultipleChoiceField(
        label="Días de la semana (opcional)",
        choices=[(str(n), nombre) for n, nombre in DIAS_SEMANA],
        required=False,
        widget=forms.CheckboxSelectMultiple(attrs={"class": "dias"}),
        help_text="Marca los días en que se repite la tarea, de lunes a viernes "
        "(por ejemplo lunes y miércoles). Déjalo vacío si no aplica.",
    )

    class Meta:
        model = Tarea
        fields = [
            "titulo",
            "descripcion",
            "responsable",
            "prioridad",
            "fecha_inicio",
            "fecha_fin",
            "dias_semana",
            "calidad",
            "porcentaje_avance",
        ]
        widgets = {
            "descripcion": forms.Textarea(attrs={"rows": 4}),
            "fecha_inicio": DateInput(),
            "fecha_fin": DateInput(),
            "porcentaje_avance": forms.NumberInput(attrs={"min": 0, "max": 100, "step": 5}),
        }

    def __init__(self, *args, usuario=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.usuario = usuario
        responsable_actual = self.instance.responsable_id if self.instance.pk else None
        if usuario is None:
            candidatos = User.objects.filter(is_active=True)
        else:
            candidatos = usuarios_asignables(usuario, responsable_actual)
        self.fields["responsable"].queryset = _usuarios_ordenados(candidatos)
        if self.instance.pk:
            self.initial["dias_semana"] = self.instance.dias_lista

    def clean_dias_semana(self):
        # Se guarda como texto: "0,2" = lunes y miércoles
        return ",".join(sorted(self.cleaned_data["dias_semana"]))


class AvanceForm(forms.ModelForm):
    """Formulario para que el responsable actualice avance y calidad (con nota opcional)."""

    nota = forms.CharField(
        label="Nota de avance (opcional)",
        required=False,
        max_length=2000,
        widget=forms.Textarea(attrs={"rows": 2, "placeholder": "¿Qué se avanzó?"}),
    )

    class Meta:
        model = Tarea
        fields = ["porcentaje_avance", "calidad"]
        widgets = {
            "porcentaje_avance": forms.NumberInput(attrs={"min": 0, "max": 100, "step": 5}),
        }


class ComentarioForm(forms.Form):
    texto = forms.CharField(
        label="Nueva nota",
        max_length=2000,
        widget=forms.Textarea(
            attrs={"rows": 3, "placeholder": "Escribe una nota de avance o un comentario…"}
        ),
    )


class ReasignarForm(forms.Form):
    nuevo_responsable = UserChoiceField(
        queryset=User.objects.none(),
        label="Reasignar a",
    )
    motivo = forms.CharField(label="Motivo (opcional)", max_length=255, required=False)

    def __init__(self, *args, tarea=None, usuario=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.tarea = tarea
        if usuario is None:
            candidatos = User.objects.filter(is_active=True)
        else:
            candidatos = usuarios_asignables(usuario)
        self.fields["nuevo_responsable"].queryset = _usuarios_ordenados(candidatos)

    def clean_nuevo_responsable(self):
        usuario = self.cleaned_data["nuevo_responsable"]
        if self.tarea and usuario == self.tarea.responsable:
            raise forms.ValidationError("Esa persona ya es la responsable de la tarea.")
        return usuario


class ImportarForm(forms.Form):
    archivo = forms.FileField(label="Archivo de Excel (.xlsx)")

    def clean_archivo(self):
        archivo = self.cleaned_data["archivo"]
        if not archivo.name.lower().endswith(".xlsx"):
            raise forms.ValidationError("El archivo debe ser de Excel (.xlsx). Usa la plantilla.")
        if archivo.size > MAX_BYTES_EXCEL:
            raise forms.ValidationError("El archivo es muy grande (máximo 5 MB).")
        return archivo


class ExportarForm(forms.Form):
    """Filtros del reporte de Excel."""

    area = forms.ModelChoiceField(
        queryset=Area.objects.all(), required=False, empty_label="Todas", label="Área"
    )
    responsable = UserChoiceField(
        queryset=User.objects.none(),
        required=False,
        empty_label="Todos",
        label="Usuario que realiza la tarea",
    )
    prioridad = forms.ChoiceField(
        choices=[("", "Todas")] + [(str(v), l) for v, l in Tarea.Prioridad.choices],
        required=False,
        label="Prioridad",
    )
    estado = forms.ChoiceField(choices=ESTADOS, required=False, label="Estado")
    campo_fecha = forms.ChoiceField(
        choices=CAMPOS_FECHA, required=False, initial="inicio", label="Aplicar el rango de fechas a"
    )
    desde = forms.DateField(required=False, widget=DateInput(), label="Desde")
    hasta = forms.DateField(required=False, widget=DateInput(), label="Hasta")
    incluir_bitacora = forms.BooleanField(
        required=False, label="Incluir hoja con comentarios y bitácora"
    )

    def __init__(self, *args, usuario, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["responsable"].queryset = _usuarios_ordenados(usuarios_asignables(usuario))
        if not es_admin(usuario):
            del self.fields["area"]  # Atención solo ve (y exporta) su área

    def clean(self):
        datos = super().clean()
        if datos.get("desde") and datos.get("hasta") and datos["desde"] > datos["hasta"]:
            self.add_error("hasta", "La fecha «hasta» no puede ser anterior a «desde».")
        return datos


class UsuarioForm(forms.Form):
    """Alta y edición de usuarios desde la app (rol Administración)."""

    nombre = forms.CharField(label="Nombre", max_length=150)
    username = forms.CharField(
        label="Usuario",
        max_length=150,
        help_text="Con este usuario inicia sesión. Letras, números y @/./+/-/_",
    )
    password1 = forms.CharField(
        label="Contraseña",
        required=False,
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}),
    )
    password2 = forms.CharField(
        label="Confirmar contraseña",
        required=False,
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}),
    )
    area = forms.ModelChoiceField(
        queryset=Area.objects.all(), required=False, empty_label="Sin área", label="Área"
    )
    rol = forms.ChoiceField(
        label="Rol", choices=PerfilUsuario.Rol.choices, initial=PerfilUsuario.Rol.ATENCION
    )
    activo = forms.BooleanField(label="Usuario activo", required=False, initial=True)

    def __init__(self, *args, instance=None, editor=None, **kwargs):
        self.instance = instance
        if instance is not None:
            perfil = getattr(instance, "perfil", None)
            kwargs["initial"] = {
                "nombre": instance.get_full_name(),
                "username": instance.username,
                "area": perfil.area_id if perfil is not None else None,
                "rol": perfil.rol if perfil is not None else PerfilUsuario.Rol.ATENCION,
                "activo": instance.is_active,
                **kwargs.get("initial", {}),
            }
        super().__init__(*args, **kwargs)
        if instance is None:
            self.fields["password1"].required = True
            self.fields["password2"].required = True
        else:
            self.fields["password1"].help_text = "Déjala vacía si no quieres cambiarla."
        if instance is not None and editor is not None and instance.pk == editor.pk:
            # Evita quedarse sin acceso: no puedes cambiar tu propio rol ni desactivarte.
            self.fields["rol"].disabled = True
            self.fields["activo"].disabled = True
            self.fields["rol"].help_text = "No puedes cambiar tu propio rol ni desactivarte."

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        User._meta.get_field("username").run_validators(username)
        existentes = User.objects.filter(username__iexact=username)
        if self.instance is not None:
            existentes = existentes.exclude(pk=self.instance.pk)
        if existentes.exists():
            raise ValidationError("Ya existe un usuario con ese nombre.")
        return username

    def clean(self):
        datos = super().clean()
        p1, p2 = datos.get("password1"), datos.get("password2")
        if p1 or p2:
            if p1 != p2:
                self.add_error("password2", "Las contraseñas no coinciden.")
            else:
                candidato = self.instance or User(
                    username=datos.get("username", ""), first_name=datos.get("nombre", "")
                )
                try:
                    validate_password(p1, user=candidato)
                except ValidationError as error:
                    self.add_error("password1", error)
        return datos

    @transaction.atomic
    def guardar(self):
        datos = self.cleaned_data
        usuario = self.instance or User()
        usuario.username = datos["username"]
        usuario.first_name = datos["nombre"]
        usuario.last_name = ""
        usuario.is_active = datos["activo"]
        if datos.get("password1"):
            usuario.set_password(datos["password1"])
        usuario.save()
        PerfilUsuario.objects.update_or_create(
            usuario=usuario, defaults={"area": datos["area"], "rol": datos["rol"]}
        )
        return usuario


class AreaForm(forms.ModelForm):
    class Meta:
        model = Area
        fields = ["nombre", "descripcion"]

    def clean_nombre(self):
        nombre = self.cleaned_data["nombre"].strip()
        existentes = Area.objects.filter(nombre__iexact=nombre).exclude(pk=self.instance.pk)
        if existentes.exists():
            raise ValidationError("Ya existe un área con ese nombre.")
        return nombre
