from django import forms
from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.forms import UserChangeForm, UserCreationForm

from .models import Area, Comentario, PerfilUsuario, Reasignacion, Tarea

User = get_user_model()


class ReasignacionInline(admin.TabularInline):
    model = Reasignacion
    extra = 0
    readonly_fields = ("de_usuario", "a_usuario", "realizada_por", "motivo", "fecha")
    can_delete = False


class ComentarioInline(admin.TabularInline):
    model = Comentario
    extra = 0
    fields = ("creado_en", "autor", "tipo", "texto")
    readonly_fields = ("creado_en", "autor", "tipo", "texto")
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Tarea)
class TareaAdmin(admin.ModelAdmin):
    list_display = (
        "titulo",
        "asignado_por",
        "responsable",
        "fecha_inicio",
        "fecha_fin",
        "area",
        "prioridad",
        "calidad",
        "porcentaje_avance",
    )
    list_filter = ("area", "prioridad", "calidad", "responsable", "asignado_por")
    search_fields = ("titulo", "descripcion")
    inlines = [ReasignacionInline, ComentarioInline]


@admin.register(Area)
class AreaAdmin(admin.ModelAdmin):
    list_display = ("nombre", "descripcion", "total_usuarios")
    search_fields = ("nombre",)

    @admin.display(description="Usuarios")
    def total_usuarios(self, obj):
        return obj.usuarios.count()


def _campos_perfil():
    return {
        "area": forms.ModelChoiceField(
            queryset=Area.objects.all(), required=False, label="Área"
        ),
        "rol": forms.ChoiceField(
            label="Rol",
            choices=PerfilUsuario.Rol.choices,
            initial=PerfilUsuario.Rol.ATENCION,
        ),
    }


class UsuarioCreacionForm(UserCreationForm):
    """Alta de usuario: nombre, usuario, contraseña, área y rol (nada más)."""

    first_name = forms.CharField(label="Nombre", max_length=150)
    area = _campos_perfil()["area"]
    rol = _campos_perfil()["rol"]

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("first_name", "username")


class UsuarioCambioForm(UserChangeForm):
    """Edición de usuario con los mismos campos que el alta."""

    area = _campos_perfil()["area"]
    rol = _campos_perfil()["rol"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        perfil = getattr(self.instance, "perfil", None) if self.instance.pk else None
        if perfil is not None:
            self.fields["area"].initial = perfil.area_id
            self.fields["rol"].initial = perfil.rol


admin.site.unregister(User)


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    add_form = UsuarioCreacionForm
    form = UsuarioCambioForm
    fieldsets = (
        (None, {"fields": ("first_name", "username", "password", "area", "rol", "is_active")}),
    )
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("first_name", "username", "password1", "password2", "area", "rol"),
            },
        ),
    )
    filter_horizontal = ()
    list_display = ("username", "first_name", "area_col", "rol_col", "is_active")
    list_filter = ("is_active", "perfil__area", "perfil__rol")
    search_fields = ("username", "first_name")
    ordering = ("username",)
    list_select_related = ("perfil__area",)

    @admin.display(description="Área")
    def area_col(self, obj):
        perfil = getattr(obj, "perfil", None)
        return perfil.area if perfil is not None and perfil.area_id else "—"

    @admin.display(description="Rol")
    def rol_col(self, obj):
        if obj.is_superuser:
            return "Administración (superusuario)"
        perfil = getattr(obj, "perfil", None)
        return perfil.get_rol_display() if perfil is not None else "Atención"

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        PerfilUsuario.objects.update_or_create(
            usuario=obj,
            defaults={"area": form.cleaned_data.get("area"), "rol": form.cleaned_data["rol"]},
        )


@admin.register(Reasignacion)
class ReasignacionAdmin(admin.ModelAdmin):
    list_display = ("tarea", "de_usuario", "a_usuario", "realizada_por", "fecha")
