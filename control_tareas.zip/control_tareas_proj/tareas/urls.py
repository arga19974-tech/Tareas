from django.urls import path

from . import gestion, views

app_name = "tareas"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("tareas/", views.lista_tareas, name="lista"),
    path("nueva/", views.crear_tarea, name="crear"),
    path("importar/", views.importar_excel, name="importar"),
    path("importar/plantilla/", views.descargar_plantilla, name="plantilla"),
    path("exportar/", views.exportar_excel, name="exportar"),
    # Administración de usuarios y áreas (rol Administración)
    path("usuarios/", gestion.usuarios_lista, name="usuarios"),
    path("usuarios/nuevo/", gestion.usuario_crear, name="usuario_crear"),
    path("usuarios/<int:pk>/editar/", gestion.usuario_editar, name="usuario_editar"),
    path("areas/", gestion.areas_lista, name="areas"),
    path("areas/nueva/", gestion.area_crear, name="area_crear"),
    path("areas/<int:pk>/editar/", gestion.area_editar, name="area_editar"),
    path("areas/<int:pk>/eliminar/", gestion.area_eliminar, name="area_eliminar"),
    # Tareas
    path("<int:pk>/", views.detalle_tarea, name="detalle"),
    path("<int:pk>/editar/", views.editar_tarea, name="editar"),
    path("<int:pk>/avance/", views.actualizar_avance, name="avance"),
    path("<int:pk>/comentarios/", views.agregar_comentario, name="comentar"),
    path("<int:pk>/reasignar/", views.reasignar_tarea, name="reasignar"),
    path("<int:pk>/eliminar/", views.eliminar_tarea, name="eliminar"),
]
