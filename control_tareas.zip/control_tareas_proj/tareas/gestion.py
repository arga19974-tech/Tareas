"""Administración de usuarios y áreas dentro de la app (solo rol Administración)."""

from functools import wraps

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render

from .forms import AreaForm, UsuarioForm
from .models import Area
from .permisos import es_admin

User = get_user_model()


def solo_admin(vista):
    @wraps(vista)
    @login_required
    def envoltura(request, *args, **kwargs):
        if not es_admin(request.user):
            return HttpResponseForbidden("Solo el rol Administración puede entrar aquí.")
        return vista(request, *args, **kwargs)

    return envoltura


def _usuarios_gestionables(request):
    """Los superusuarios solo los ven otros superusuarios."""
    usuarios = User.objects.select_related("perfil__area")
    if not request.user.is_superuser:
        usuarios = usuarios.filter(is_superuser=False)
    return usuarios


@solo_admin
def usuarios_lista(request):
    usuarios = _usuarios_gestionables(request).order_by("username")
    q = request.GET.get("q", "").strip()
    if q:
        usuarios = usuarios.filter(Q(username__icontains=q) | Q(first_name__icontains=q))
    area = request.GET.get("area", "")
    if area.isdigit():
        usuarios = usuarios.filter(perfil__area_id=int(area))
    else:
        area = ""
    return render(
        request,
        "tareas/usuarios_lista.html",
        {"usuarios": usuarios, "q": q, "area": area, "areas": Area.objects.all()},
    )


@solo_admin
def usuario_crear(request):
    form = UsuarioForm(request.POST or None, editor=request.user)
    if request.method == "POST" and form.is_valid():
        usuario = form.guardar()
        messages.success(request, f"Usuario «{usuario.username}» creado.")
        return redirect("tareas:usuarios")
    return render(
        request,
        "tareas/gestion_form.html",
        {"form": form, "titulo_pagina": "Nuevo usuario", "volver": "tareas:usuarios"},
    )


@solo_admin
def usuario_editar(request, pk):
    usuario = get_object_or_404(_usuarios_gestionables(request), pk=pk)
    form = UsuarioForm(request.POST or None, instance=usuario, editor=request.user)
    if request.method == "POST" and form.is_valid():
        form.guardar()
        messages.success(request, f"Usuario «{usuario.username}» actualizado.")
        return redirect("tareas:usuarios")
    return render(
        request,
        "tareas/gestion_form.html",
        {
            "form": form,
            "titulo_pagina": f"Editar usuario: {usuario.username}",
            "volver": "tareas:usuarios",
        },
    )


@solo_admin
def areas_lista(request):
    areas = Area.objects.annotate(
        n_usuarios=Count("usuarios", distinct=True), n_tareas=Count("tareas", distinct=True)
    )
    return render(request, "tareas/areas_lista.html", {"areas": areas})


@solo_admin
def area_crear(request):
    form = AreaForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        area = form.save()
        messages.success(request, f"Área «{area.nombre}» creada.")
        return redirect("tareas:areas")
    return render(
        request,
        "tareas/gestion_form.html",
        {"form": form, "titulo_pagina": "Nueva área", "volver": "tareas:areas"},
    )


@solo_admin
def area_editar(request, pk):
    area = get_object_or_404(Area, pk=pk)
    form = AreaForm(request.POST or None, instance=area)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Área actualizada.")
        return redirect("tareas:areas")
    return render(
        request,
        "tareas/gestion_form.html",
        {"form": form, "titulo_pagina": f"Editar área: {area.nombre}", "volver": "tareas:areas"},
    )


@solo_admin
def area_eliminar(request, pk):
    area = get_object_or_404(Area, pk=pk)
    n_usuarios = area.usuarios.count()
    n_tareas = area.tareas.count()
    bloqueada = bool(n_usuarios or n_tareas)
    if request.method == "POST":
        if bloqueada:
            messages.error(request, "No se puede eliminar un área que tiene usuarios o tareas.")
        else:
            area.delete()
            messages.success(request, "Área eliminada.")
        return redirect("tareas:areas")
    return render(
        request,
        "tareas/area_eliminar.html",
        {"area": area, "n_usuarios": n_usuarios, "n_tareas": n_tareas, "bloqueada": bloqueada},
    )
